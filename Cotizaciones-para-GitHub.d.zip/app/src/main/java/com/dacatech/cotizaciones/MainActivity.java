package com.dacatech.cotizaciones;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import org.json.JSONObject;

import java.io.File;

public class MainActivity extends Activity {
    private static final int REQ_FILE = 1001;
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF0B1117);
        root.addView(web, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                v.setPadding(0, insets.getSystemWindowInsetTop(), 0, insets.getSystemWindowInsetBottom());
                return insets.consumeSystemWindowInsets();
            }
        });
        root.requestApplyInsets();
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);

        web.addJavascriptInterface(new Object() {
            @JavascriptInterface public void sharePdf(final String json, final String via, final String to, final String subject) {
                doSharePdf(json, via, to, subject);
            }
            @JavascriptInterface public void printPage(final String title) {
                runOnUiThread(new Runnable() { @Override public void run() {
                    String job = title.replaceAll("[^\\p{L}\\p{N} ._-]", "_");
                    PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                    PrintAttributes attrs = new PrintAttributes.Builder()
                        .setMediaSize(PrintAttributes.MediaSize.NA_LETTER)
                        .setMinMargins(new PrintAttributes.Margins(400, 400, 400, 400))
                        .build();
                    pm.print(job, web.createPrintDocumentAdapter(job), attrs);
                }});
            }
            @JavascriptInterface public void shareText(final String text) {
                runOnUiThread(new Runnable() { @Override public void run() {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_TEXT, text);
                    startActivity(Intent.createChooser(i, "Enviar cotización"));
                }});
            }
            @JavascriptInterface public void shareWhatsApp(final String text) {
                runOnUiThread(new Runnable() { @Override public void run() {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_TEXT, text);
                    i.setPackage("com.whatsapp");
                    try { startActivity(i); }
                    catch (Exception e) { i.setPackage(null); startActivity(Intent.createChooser(i, "Enviar cotización")); }
                }});
            }
            @JavascriptInterface public void sendEmail(final String to, final String subject, final String body) {
                runOnUiThread(new Runnable() { @Override public void run() {
                    Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"));
                    if (to != null && to.length() > 0) i.putExtra(Intent.EXTRA_EMAIL, new String[]{to});
                    i.putExtra(Intent.EXTRA_SUBJECT, subject);
                    i.putExtra(Intent.EXTRA_TEXT, body);
                    try { startActivity(Intent.createChooser(i, "Enviar por correo")); }
                    catch (Exception e) { Toast.makeText(MainActivity.this, "No hay app de correo", Toast.LENGTH_LONG).show(); }
                }});
            }
        }, "Android");

        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                return !"file".equals(u.getScheme()) && !"about".equals(u.getScheme());
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this).setMessage(message)
                    .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int w) { result.confirm(); } })
                    .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int w) { result.cancel(); } })
                    .setOnCancelListener(new DialogInterface.OnCancelListener() {
                        @Override public void onCancel(DialogInterface d) { result.cancel(); } })
                    .show();
                return true;
            }
            @Override public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this).setMessage(message)
                    .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int w) { result.confirm(); } })
                    .setOnCancelListener(new DialogInterface.OnCancelListener() {
                        @Override public void onCancel(DialogInterface d) { result.confirm(); } })
                    .show();
                return true;
            }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                try { startActivityForResult(params.createIntent(), REQ_FILE); }
                catch (Exception e) { fileCallback = null; return false; }
                return true;
            }
        });
        web.loadUrl("file:///android_asset/index.html");
    }

    private void doSharePdf(String json, final String via, final String to, final String subject) {
        try {
            JSONObject j = new JSONObject(json);
            String safe = j.optString("file", "cotizacion").replaceAll("[^\\p{L}\\p{N} ._-]", "_") + ".pdf";
            File dir = new File(getCacheDir(), "exports");
            dir.mkdirs();
            File f = new File(dir, safe);
            new PdfMaker(this).build(j, f);
            final Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", f);
            final String text = j.optString("numero") + " - " + j.optString("nombre");
            runOnUiThread(new Runnable() { @Override public void run() { sendPdf(uri, via, to, subject, text); } });
        } catch (Exception e) {
            runOnUiThread(new Runnable() { @Override public void run() {
                Toast.makeText(MainActivity.this, "No se pudo crear el PDF", Toast.LENGTH_LONG).show();
            }});
        }
    }

    private void sendPdf(Uri uri, String via, String to, String subject, String text) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("application/pdf");
        i.putExtra(Intent.EXTRA_STREAM, uri);
        i.putExtra(Intent.EXTRA_TEXT, text);
        i.setClipData(ClipData.newRawUri("", uri));
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        if ("wa".equals(via)) {
            i.setPackage("com.whatsapp");
            try { startActivity(i); return; } catch (Exception e) { i.setPackage(null); }
            startActivity(Intent.createChooser(i, "Enviar PDF"));
        } else {
            if (to != null && to.length() > 0) i.putExtra(Intent.EXTRA_EMAIL, new String[]{to});
            i.putExtra(Intent.EXTRA_SUBJECT, subject);
            startActivity(Intent.createChooser(i, "Enviar PDF por correo"));
        }
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_FILE && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCallback = null;
            return;
        }
        super.onActivityResult(req, res, data);
    }

    @Override public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
